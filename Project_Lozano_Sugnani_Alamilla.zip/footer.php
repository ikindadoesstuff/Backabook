<footer>
    <!-- <h1>Welcome to Backabook Bookstore</h1> -->
    <img src="img/icon2.png" width="100" height="100">
    <div class="footerbackground">
        <div class="footer">
            <div class="footerinfo">
                <div class="footerinfotitle">
                    More Info
                </div>
                <div class="line"></div>
                Backabook Bookstore, Belize's most trusted and comprehensive bookstore, can assist you in acquiring
                Belize's finest
                books that are available to help you achieve your academic goals.
            </div>
            <div class="footerinfo">
                <div class="footerinfotitle">
                    Contact Details
                </div>
                <div class="line"></div><br><br>
                LOCATION: Landivar Campus, Princess Margaret Dr, Belize City, Belize<br><br>
                PHONE: (501) 6151234<br><br>
                EMAIL: info@backabook.bz<br><br>
            </div>
        </div>
    </div>
</footer>